﻿var navbar;
var nextElement;
var touchIsDragging = false;
let touchEvent = 'ontouchend' in window ? 'touchend' : 'click';


/* When this function is called, the user pressed the Android hardware back button */
function backButtonPress() {

    //First, make sure a back button exists
    if ($('.btnBack').length > 0) {
        if ($('.btnBack')[0].href.length > 1 && $('.btnBack')[0].href.indexOf('history.back') === -1) {
            showLoader();
            window.location.href = $('.btnBack')[0].href;
            return false;
        }
        else {
            showLoader();
            history.back();
            return false;
        }
    }
    else if (window.location.pathname.toUpperCase().indexOf('ACCOUNTS/INDEX') > -1) {
        if (navigator.notification !== undefined) {
            //Prompt for logout
            navigator.notification.confirm('Are you sure you want to Logout?',
                function (buttonIndex) { //ButtonIndex 1 = OK, 2 = Cancel
                    if (buttonIndex !== 1) {
                        return false;
                    }
                    else {
                        showLoader();
                        window.location = '/sso/Mobile/Auth/Logout';
                    }
                });
        }
        else {
            if (confirm('Are you sure you want to Logout?')) {
                showLoader();
                window.location = '/sso/Mobile/Auth/Logout';
            }
            else {
                return false;
            }
        }

    }
    else {
        showLoader();
        window.location = '/sso/Mobile/Routing/Index';
    }
}

// Mobi Beta code --------------------------------- MRN - I think this whole listener can be removed after beta // 
$(document).on('ajaxComplete', function () {

    // Keeps the toggle button images aligned with the checkboxes behind them.  This one is specific for the main login page, since we can't bind to all the JQT events yet at that point.
    $(".toggle").each(function (index) {
        var targetElement = $(this).find("input[type='checkbox']");

        if (targetElement.prop('checked')) {
            $(this).css('background-position-x', '0px');
        }
        else {
            $(this).css('background-position-x', '-55px');
        }
    });

});

$(document).on('submit', 'form', function () {
    $('input[type=submit]').attr('disabled', 'disabled');
    showLoader();
});

$(document).on('touchmove', 'a', function (e) {
    touchIsDragging = true;
});

$(document).on(touchEvent, 'a', function () {
    var theHref = $(this).attr('href');

    if (theHref !== "#" && theHref !== undefined && !$(this).hasClass('no-spinner') && !$(this).hasClass('statementLink') && !$(this).hasClass('noticeLink') && !$(event.target).hasClass('contextMenuIcon')) {

        if (touchEvent.toLowerCase() !== 'click') //the 'touch' events block the hyperlink from redirecting, so we need to do it ourselves
        {
            if (!touchIsDragging && theHref.indexOf('tel:') === -1) {
                showLoader();
                window.location = theHref;
            }

            touchIsDragging = false;

            if (event.cancelable) //Chrome this is false, but for iOS it's true, and needed 
            {
                return false;
            }
        }

        touchIsDragging = false;
        return true;
    }
});

function showLoader() {
    $('#progressBackground').show();

    if ($('#progressBackground').prev().is('iframe')) { //iOS wedges the 'gap' control between the loader div and the main content div.  This will account for that.
        $('#progressBackground').prev().prev().css('opacity', '.4');
    }
    else {
        $('#progressBackground').prev().css('opacity', '.4');
    }
}

function hideLoader() {
    $('#progressBackground').hide();

    if ($('#progressBackground').prev().is('iframe')) { //iOS wedges the 'gap' control between the loader div and the main content div.  This will account for that.
        $('#progressBackground').prev().prev().css('opacity', '1');
    }
    else {
        $('#progressBackground').prev().css('opacity', '1');
    }
}

//Detect browser support for pageHide
if ('onpagehide' in window) {
    window.addEventListener('pagehide', showLoader, false);
}
else {
    window.addEventListener('unload', showLoader, false);
}

function openInHouseOAO() {

    showLoader();

    $.ajax({
        url: "/sso/ob/oao/GetOAOTokenizedUrl",
        type: "GET",
        cache: false,
        contentType: false,
        processData: false,
        success: function (data) {
            // If the data returned is null, we have an error.
            if (data === null) {
                if (defaultOAOInHouseLink !== undefined) {
                    hideLoader();
                    loadExternalURL(defaultOAOInHouseLink); return false;
                }
                else {
                    window.location = "/sso/Mobile/Error/Error";
                    hideLoader();
                }
            }
            else {
                hideLoader();
                loadExternalURL(data); return false;
            }
        },
        error: function () {
            window.location = "/sso/Mobile/Error/Error";
            hideLoader();
        }
    });
}

$(document).ready(function () {

    $(document).bind('backbutton', backButtonPress);

    // automatically fill out DevicePrint if it is needed
    if ($("#DevicePrint").length > 0) {
        $("#DevicePrint").val(encode_deviceprint());
    }

    disableAutocomplete();
    $('#progressBackground').hide();

    fixiOSToolbar(); //Remove this after we deploy the new iOS version for the Cordova update

});

function disableAutocomplete() {
    if ($('form').length > 0) {
        $('form').attr('autocomplete', 'off');
    }
    else {
        $('input').attr('autocomplete', 'off');
    }
}

function assignMask(hiddenfield, maskfield) {
    
    var actualInputUN = $(maskfield).val().trim();

    //If there's no value in the hidden field, no need to worry about re-masking
    if ($(hiddenfield).val().length === 0 || actualInputUN.indexOf('****') == -1) //Prevent re-masking
    {
        $(hiddenfield).val(actualInputUN);
        userAsteriskCount = 0; //reset the count

        if (actualInputUN.length > 4) {

            $(maskfield).val(actualInputUN.substring(0, 4) + '****');
        }
        else {
            if (actualInputUN.length > 0) {
                $(maskfield).val(actualInputUN + '****');
            }
        }
    }   
    else //The hidden field is already populated, but the user possibly entered a username with 4+ asterisks.  How to we determine the difference between a masked username and a user-entered asterik
    {
        if (actualInputUN.indexOf('****') > -1) { //Check to see if the asterisks in the username box were user-entered, or a result of masking
            if (typeof (userAsteriskCount) !== "undefined" && userAsteriskCount > 0) {

                //Check to see if the count of user-entered asterisks matches how many are in the input box
                var inputBoxAsteriskCount = $(maskfield).val().split("*").length - 1; //Split is faster than using a regex and counting the matches.

                if (userAsteriskCount === inputBoxAsteriskCount) {
                    if (actualInputUN.length > 4) {

                        $(maskfield).val(actualInputUN.substring(0, 4) + '****');
                        $(hiddenfield).val(actualInputUN);
                    }
                    else {
                        if (actualInputUN.length > 0) {
                            $(maskfield).val(actualInputUN + '****');
                            $(hiddenfield).val(actualInputUN);
                        }
                    }

                    userAsteriskCount = 0; //reset the count
                }
                else {
                    //do nothing, just reset the count
                    userAsteriskCount = 0;
                }
            }
        }           
    }
}

//Load a url in a new tab or window
function loadExternalURL(href) {
    //Cordova get cranky without the full URL
    var newURL = "";

    //Make sure we don't already have a full url in our hands
    if (href.toUpperCase().indexOf("HTTPS://") > -1) {
        newURL = href;
    }
    else {
        newURL = "https://" + window.location.host + href;
    }

    //See if we can use the inAppBrowser plugin
    if (typeof (cordova) !== "undefined") {
        if (cordova.InAppBrowser !== undefined) {
            cordova.InAppBrowser.open(newURL, '_system');
        } else {
            if (cordova.platformId === 'android') {

                if (navigator.app === undefined) {
                    window.open(newURL, '_blank');
                } else {
                    navigator.app.loadUrl(newURL, { openExternal: true });
                }
            } else {
                window.open(newURL, '_system');
            }
        }
    } else {
        window.open(newURL, '_system');
    }
}

//Does the current browser support inline viewing of pdf files?
function isPDFSupportedBrowser() {

    if (navigator.plugins.length > 0) {
        for (i = 0; i < navigator.plugins.length; i++) {
            if (navigator.plugins[i][0].suffixes.indexOf('pdf') > -1) {
                return true;
            }
        }
    }

    return false;
}

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) === 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

function deleteCookie(cname, path) {
    var name = cname + "=";
    document.cookie = name + ";expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path;
}

// This function prevents the smartphone from auto-formatting multi-digit numbers into a phone number.
function preventPhoneNumberAutoFormatting() {
    $("head").append("<meta name='format-detection' content='telephone=no'>");
}

var MIDFLORIDAMobileCommon = (function ($) {
    return {
        //This function is designed in order to generate a GUID
        GenerateGUID: function () {
            var d = new Date().getTime();
            var guid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });

            return guid;
        },
        //This function will make the API call based on the properties passed to it.
        MakeAjaxCall: function (dataObject, headerObject, method, url, successCallback, failureCallback) {
            $.ajax({
                url: url,
                type: method,
                data: dataObject,
                cache: false, //If set to false, it will force requested pages not to be cached by the browser.
                headers: {}, //An object of additional header key/value pairs to send along with requests using the XMLHttpRequest transport.
                async: true, //If async is set to 'true', all requests are sent asynchronously
                dataType: 'json', //The type of data that you're expecting back from the server. If none is specified, jQuery will try to infer it based on the MIME type of the response
                contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                /*
                 * Before sending the request to the server, set the proper values in the header
                 * of the request if applicable. For example if we attemnpt to make a call to the
                 * WebAPI, the request verification token must be assigned to the header. in order
                 * to achieve this behavior, this function will do just that.
                 */
                beforeSend: function (xhr) {
                    /*
                     * Check to ensure that header properties are present prior to looping through
                     * the property of the JSON object and attempt to assign values to the header.
                     * If the object is null or undefined than this is an indication that no values
                     * must be appended to the header.
                     */
                    if (headerObject !== null && headerObject !== undefined) {
                        //Loop through the JSON properties and assign them to the header of the request.
                        for (var key in headerObject) {
                            if (headerObject.hasOwnProperty(key)) {
                                var val = headerObject[key];
                                xhr.setRequestHeader(key, val);
                            }
                        }
                    }
                },
                success: function (data, textStatus, jqXHR) {
                    //Check to determine whether the parameter passed in is of type "Function". If so execute the callback.
                    if (typeof (successCallback) === typeof (Function)) {
                        successCallback(data, textStatus, jqXHR);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    //Check to determine whether the parameter passed in is of type "Function". If so execute the callback.
                    if (typeof (failureCallback) === typeof (Function)) {
                        failureCallback(jqXHR, textStatus, errorThrown);
                    }
                }
            });
        },
        //This function is designed in order to log client side errors to the server.
        LogError: function (logErrorRequest, headerObject) {
            if (logErrorRequest) {
                logErrorRequest.RequestID = this.GenerateGUID();
                logErrorRequest.ErrorToLog = logErrorRequest.ErrorToLog; //This will get sanitized in the WebAPI

                //Make a call to save the net worth object.
                this.MakeAjaxCall(logErrorRequest, headerObject, 'POST', '/sso/api/Logging/Log');
            }
        }
    };
})(jQuery);

// --- These function address the IOS fixed header issue when the mobile scroll wheel or the virtual keyboard open ---- //
function fixFixed() {
    if (typeof cordova !== 'undefined') {
        if (cordova.platformId === 'ios') { // this is only necessary for ios devices
            var $body = jQuery('body');
            $body.addClass('fixfixed');
        }
    }
}

function unFixFixed() {
    var $body = jQuery('body');
    $body.removeClass('fixfixed');
}

function fixiOSToolbar() {
    try {
        if (navigator.platform.toUpperCase() == "IPHONE")
        {
            if (navigator.appVersion.includes("16_4") || navigator.appVersion.includes("16_5") || navigator.appVersion.includes("16_6")) {
                $('.toolbar').addClass('toolbar-16-4-fix');
            }
        }
    }
    catch {
        //Just eat it.  We just don't want this temporary fix to get in the way of anything else in the app
    }
}

// Validate input for numbers only
function TextboxNumericsOnly() {
    $(".NumericOnly").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, and enter
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 ||
            // Allow: Ctrl/cmd+A
            (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl/cmd+C
            (e.keyCode == 67 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl/cmd+V
            (e.keyCode == 86 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: Ctrl/cmd+X
            (e.keyCode == 88 && (e.ctrlKey === true || e.metaKey === true)) ||
            // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
            // let it happen, don't do anything
            return;
        }
        // Ensure that it is a number (main or numbpad) and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
}

/*** Native PDF document download functions (Statements, Tax Forms, Notices) ***/
function iOSPathFallback() {
    var currentPath = localStorage.getItem('rootStoragePath');
    var availablePaths = cordova.file;

    if ((currentPath === null) || (currentPath === "null") || currentPath === availablePaths.documentsDirectory || currentPath.indexOf("/Documents") > -1) {
        localStorage.setItem('rootStoragePath', availablePaths.dataDirectory);
    }
    else if (currentPath === availablePaths.dataDirectory) //If they are already using the dataDirectory, fallback to cache directory
    {
        localStorage.setItem('rootStoragePath', availablePaths.cacheDirectory);
    }
    else if (currentPath === availablePaths.cacheDirectory) //If they are already using the cacheDirectory, fallback to tempDirectory
    {
        localStorage.setItem('rootStoragePath', availablePaths.tempDirectory);
    }
    else if (currentPath === availablePaths.tempDirectory) //If they are already using the tempDirectory, loop back to dataDirectory
    {
        localStorage.setItem('rootStoragePath', availablePaths.dataDirectory);
    }
    else //After an iOS update, the phone 'guid' changes thus changing the filepaths returned by the plugin.  So the currentPath comparisons above will fail, and never rotate to a new download path.
    {
        //Just reset to the current dataDirectory. This will ensure the correct 'guid' is baked into the filepath
        localStorage.setItem('rootStoragePath', availablePaths.dataDirectory);
    }
}

//Hits the cordova plugin to get a valid path for downloading files.  If the plugin does not return a meaningful value,
// it will fallback and used the cached value we keep in localStorage
function getStoragePathToUse()
{
    //Make sure the rootStoragePath is filled in.  IF not, try again to fill it in
    if ((localStorage.getItem('rootStoragePath') === null) || (localStorage.getItem('rootStoragePath') === "null")) {
        localStorage.setItem('rootStoragePath', cordova.file.dataDirectory); //ios does not return/support the externalRootDirectory
    }

    //Try to get the path from the plugin first, and only use the localStorage cached version if needed
    var storagePathToUse = cordova.file.dataDirectory;

    //If the plugin failed to return a good value, fallback to the localStorage version
    if (typeof (storagePathToUse) === "undefined" || storagePathToUse === '' || storagePathToUse === null) {
        storagePathToUse = localStorage.getItem('rootStoragePath');
    }

    return storagePathToUse;
}

//Specific logger for errors related to mobile document downloads
function LogDocumentDownloadError(errorObject, source, message) {
    try {

        var requestObj;
        var header;

        if (errorObject) {
            var errorToLog = "";

            if (errorObject.stack && errorObject.stack !== '')
                errorToLog = errorObject.stack;
            else
                errorToLog = errorObject.message;

            requestObj = {
                ErrorToLog: errorToLog,
                ClientSource: source,
                RequestID: null,
                antiForgeryToken: $("input[name='__RequestVerificationToken']").val(),
                ErrorCode: "Mobi_STMT"
            };

            //Check to ensure that the anti-forgery token is present prior to attempting to save the form
            if (requestObj.antiForgeryToken && requestObj.antiForgeryToken !== '') {

                header = {
                    RequestVerificationToken: requestObj.antiForgeryToken
                };

                MIDFLORIDAMobileCommon.LogError(requestObj, header);
            }
        }
        else //Just log the message if no exception object was passed
        {
            requestObj = {
                ErrorToLog: message,
                ClientSource: source,
                RequestID: null,
                antiForgeryToken: $("input[name='__RequestVerificationToken']").val(),
                ErrorCode: "Mobi_STMT"
            };

            //Check to ensure that the anti-forgery token is present prior to attempting to save the form
            if (requestObj.antiForgeryToken && requestObj.antiForgeryToken !== '') {

                header = {
                    RequestVerificationToken: requestObj.antiForgeryToken
                };

                MIDFLORIDAMobileCommon.LogError(requestObj, header);
            }
        }
    }
    catch (e) {
        //At this point the failing mechanism has also failed and there is nothing
        //we can do other than silencing the exception.
    }
}