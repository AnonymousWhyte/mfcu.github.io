﻿/// This Object will hold the values and the methods needed to
/// authenticate members via Touch
var ClientTouchAuthenticate = (function ($) {
    return {
        PopulateBioAuthErrorMessages: function () {

            TouchID.getBiometricType(
                function (bioType) {
                    var bioAuthText = "Biometric Authentication";

                    if (bioType === "TOUCH") {
                        bioAuthText = "Touch ID";
                    } else if (bioType === "FACE") {
                        bioAuthText = "Face ID";
                    }

                    ClientTouchAuthenticate.LoginMustReAuthMessage = "We have detected a change to your " + bioAuthText + " settings on this device. For your security, please log on with your username and password.";
                    ClientTouchAuthenticate.LoginToSetupTouchLoginMessage = "Please log on with your username and password to turn on " + bioAuthText;
                    ClientTouchAuthenticate.EnableDeviceSettingsMessage = "Please enable " + bioAuthText + " in your device settings.";
                    ClientTouchAuthenticate.BiometricAuthenticationConfirmationMessage = "Would you like to enable " + bioAuthText + " for login?";
                    ClientTouchAuthenticate.BiometricAuthenticationConfirmationTitle = bioAuthText;
                    ClientTouchAuthenticate.BiometricAuthenticationConfirmationButtonLabels = "Yes,No";
                },
                function (failMessage) {
                });
        },
        //This is the url which will be used in order to post to the server to enable touch ID feature.
        EnableTouchPostURL: "/sso/Mobile/Touch/EnableTouch",
        // This property will hold the message passed to the member 
        // when a re-auth is required 
        LoginMustReAuthMessage: "We have detected a change to your Biometric Authentication settings on this device. For your security, please log on with your username and password.",
        //This property will hold the message for alerting the user their bio authentication method is not setup
        EnableDeviceSettingsMessage: "Please enable Biometric Authentication in your device settings.",
        //This is the page that we will be using to redirect the member to in the event an error has occurred.
        ErrorPage: '/sso/Mobile/Error/Error',
        // This property will hold the message used when the touch screen is presented
        LoginToSetupTouchLoginMessage: "Please log on with your username and password to turn on Biometric Authentication",
        //The following properties are used for allowing the user to break out of biometric auth
        BiometricAuthenticationConfirmationMessage: "Would you like to enable Biometric Authentication for login?",
        BiometricAuthenticationConfirmationTitle: "Biometric Authentication",
        BiometricAuthenticationConfirmationButtonLabels: "Yes,No",
        BiometricAuthenticationAndroidTempLockoutMessage: "Biometric Authentication failed too many times.  Biometrics will be unavailable for at least 30 seconds.  Username and password may still be used during this time.",
        BiometricAuthenticationAndroidPermLockoutMessage: "Biometric Authentication has been locked out too many times. Biometrics will be unavailable until the device is unlocked using a different method. (Pin, Password, Pattern, etc)",
        BiometricAuthenticationAndroidTempLockoutMessageEnrollment: "Biometric Authentication failed too many times.  Biometrics will be unavailable for at least 30 seconds.",
        // This method will call persist credentials in the device and send them via ajax
        // to be persisten in our OnlineBanking database.
        ResetTouchCredentials: function (touchID) {

            // Successful callback from persistCredentials
            // Once a successful call is made this will call the EnableTouchFeature that will take care of
            // ajaxing the username and password to the Touch controller
            function persistCredentialsSuccessful(data) {
                var jsonParse = JSON.parse(data);
                //Determine whether the json parse value is not null or undefined.
                if (jsonParse) {
                    var afToken = $("input[name='__RequestVerificationToken']").val();

                    if (afToken && afToken !== "") {

                        var enableTouchFeatureData = null;
                        //This is the data in a json object which will be used in to be passed in to the data option as an object when making the ajax call
                        enableTouchFeatureData = {
                            "TouchID": jsonParse.TouchID,
                            "Password": jsonParse.TouchPassword,
                            "DeviceDescription": jsonParse.DeviceDescription,
                            "__RequestVerificationToken": afToken
                        };

                        if (jsonParse.TouchIDIV !== undefined) {
                            // we have a TouchIV back from the persistCredential call. Pass it along to our enable Touch POST
                            enableTouchFeatureData.TouchID_IV = jsonParse.TouchIDIV;
                        }

                        if (jsonParse.PasswordIV !== undefined) {
                            // we have a PasswordIV back from the persistCredential call. Pass it along to our enable Touch POST
                            enableTouchFeatureData.Password_IV = jsonParse.PasswordIV;
                        }

                        //Fire the enable feature call to save the information on the server side.
                        ClientTouchCommon.MakeAjaxCall(enableTouchFeatureData, null, "POST", ClientTouchAuthenticate.EnableTouchPostURL, enableTouchSuccess, enableTouchFailure);
                    }
                } else {
                    window.location = ClientTouchAuthenticate.ErrorPage;
                }
            }

            // Failure callback from persist credentials
            // redirect to the error page
            function persistCredentialsFailure() {
                window.location = (ClientTouchAuthenticate.ErrorPage);
            }

            function enableTouchSuccess() {
                // remove TouchID value from the client, we are done with it at this point and don't need it again
                $("#TouchID").val("");

                // perform redirect
                window.location = "/sso/Mobile/Settings/TouchIDCredentialsReset";
            }

            function enableTouchFailure() {
                window.location = ("/sso/Mobile/Settings/TouchIDCredentialsReset");
            }

            try {
                // Create new credentials on the device
                TouchID.persistCredentials(touchID,
                    persistCredentialsSuccessful,
                    persistCredentialsFailure);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.ToggleTouchFeature()", ClientTouchAuthenticate.ErrorPage);
            }
        },
        //This function is designed in order to login the member with touch.
        LoginWithTouch: function (wasAutoFire = true) {

            // Success callback function called by TouchID.IsAvailable
            // turns around and immediately checks for HasUserData
            function touchIsAvailableSuccess() {
                TouchID.hasUserData(touchHasDataSuccess, function () { });
            }

            function touchIsAvailableFailure(callbackData) {

                try {
                    var failureInfo = JSON.parse(callbackData);

                    if (failureInfo) {
                        //failureInfo.ErrorCode === "-7" is the case where a supported device does not have any touch/face profiles setup on the device.
                        if (!wasAutoFire) {
                            navigator.notification.alert(ClientTouchAuthenticate.EnableDeviceSettingsMessage);
                        }
                    }

                }
                catch (ex) {
                    //fall through to manual login.  Is there a way we can log this?
                }

            }

            // Success callback function called by TouchID.HasData
            // Shows the touchID icon on the login screen and attempts to log
            // the member in via Touch
            function touchHasDataSuccess() {
                TouchID.validateUser(ClientTouchAuthenticate.LoginMessage, touchValidateSuccessful, touchValidateFailure, $("#hfTouchIDIV").val(), $("#hfTouchPasswordIV").val());
            }

            // Success Callback function called by TouchID.validateUser
            // This method is called when we successfully retrieved credentials
            // from validateUser.  Grab the credentials from logindata and put them
            //in hidden fields in the form and post the form.
            function touchValidateSuccessful(loginData) {
                try {
                    var loginObject;
                    var isValidJSON = ClientTouchCommon.IsValidJSON(loginData);

                    if (isValidJSON) {
                        loginObject = loginData; //For android, we don't need the additional JSON.parse, since the data that comes back is already proper
                    }
                    else {
                        loginObject = JSON.parse(loginData);
                    }
                    
                    //check our json object
                    if (loginObject) {
                        //put the touchID and password in the correct fields
                        $("#hfTouchID").val(loginObject.TouchID);
                        $("#hfTouchPassword").val(loginObject.TouchPassword);

                        // Based on timing, the device print on the form may be empty when we attempt the auto post
                        // resulting in a bogus challenge.  This will fill the device print if it is empty prior to the
                        // post.
                        if ($("#DevicePrint").length > 0) {
                            $("#DevicePrint").val(encode_deviceprint());
                        }

                        //post the form
                        $("#loginForm").submit();
                    }
                }
                catch (exception) {
                    //Let any failures fall through to manual login
                }
                // Let any other failures fall through to manual login
            }

            // Failure callback function called from TouchID.validateuser
            // This method is called when we failed to recieve credentials from validate user.
            // Check the failureData for any known errors.  Any unknown errors will result in 
            function touchValidateFailure(failureData) {
                try {
                    var failureObject = JSON.parse(failureData);
                    if (failureObject) {
                        switch (failureObject.ErrorCode) {
                            case 'MUSTREAUTH':
                                // Show message to member and set hidden field for login session saving.
                                navigator.notification.alert(ClientTouchAuthenticate.LoginMustReAuthMessage, function () { }, '', 'OK'); // The no length string is the title.  We will not be providing a title for these messages.
                                $("#hfTouchSetup").val(true);
                                hideLoader();
                                break;
                            case '-128': // indicates the user canceled the touch login
                                // fall through to manual login
                                hideLoader();
                                break;
                            case '-25293': // indicates Touch authentication failed
                                // fall through to manual login
                                hideLoader();
                                break;
                            case '-8': // indicates biometry is locked out
                                // fall through to manual login
                                hideLoader();
                                break;
                            case 'NO_IV':
                                navigator.notification.alert(ClientTouchAuthenticate.LoginMustReAuthMessage, function () { }, '', 'OK'); // The no length string is the title.  We will not be providing a title for these messages.
                                $("#hfTouchSetup").val(true);
                                hideLoader();
                                break;
                            case '10': // User dismissed the biometric prompt on purpose.                                
                                hideLoader();
                                break;
                            case '13': // User dismissed the biometric prompt on purpose with CANCEL button.                                
                                hideLoader();
                                break;
                            case '7': // User failed biometrics 5x in a row.  They have to wait 30 seconds.
                                hideLoader();
                                navigator.notification.alert(ClientTouchAuthenticate.BiometricAuthenticationAndroidTempLockoutMessage, function () { }, '', 'OK');
                                break;
                            case '9': // User got ERROR_LOCKOUT (case 7) too many times.  Biometrics will be disabled until the device is unlocked with device credential
                                navigator.notification.alert(ClientTouchAuthenticate.BiometricAuthenticationAndroidPermLockoutMessage, function () { }, '', 'OK');
                                break;
                            case '5': // Android - Prompt was dismissed due to error
                                hideLoader();
                                break;
                            case '3': // Timeout.  User sat on the prompt too long
                                hideLoader();
                                break;
                            default:
                                navigator.notification.alert(ClientTouchAuthenticate.LoginMustReAuthMessage, function () { }, '', 'OK'); // The no length string is the title.  We will not be providing a title for these messages.
                                hideLoader();
                                break;
                        }
                    }

                    //unblur the thumbprint that is in place to prevent double-click
                    if ($('.thumbprint').length > 0)
                    {
                        $('.thumbprint').css('filter', 'blur(0em)')
                    }
                }
                catch (exception) {
                    //fall through to manual login
                }
            }

            // Checks to see if the device supports Touch Auth
            TouchID.isAvailable(touchIsAvailableSuccess, touchIsAvailableFailure);
        },
        // set flag so that we can route to touch login settings screen upon login
        ActivateTouchLoginSettingsRoute: function () {
            // if the user tapped the fingerprint image without having touch login already setup in mobile, set flag so we will redirect to the TouchID settings page after login, we will also display a message letting them know to login to be able to turn it on
            TouchID.hasUserData(function () { }, function () {

                navigator.notification.confirm(
                    ClientTouchAuthenticate.BiometricAuthenticationConfirmationMessage,
                    confirmUserBiometricAuthenticationSelection,
                    ClientTouchAuthenticate.BiometricAuthenticationConfirmationTitle,
                    ClientTouchAuthenticate.BiometricAuthenticationConfirmationButtonLabels);

                function confirmUserBiometricAuthenticationSelection(buttonIndex) {
                    if (buttonIndex === 1) {
                        navigator.notification.alert(ClientTouchAuthenticate.LoginToSetupTouchLoginMessage, function () { $('#hfTouchSettingsRedirect').val(true); }, '', 'OK');
                    }
                }

            });
        },
        // setup the main thumbprint button on the auth screen
        SetupTouchButton: function () {

            function touchIsAvailableSuccess() {
                $("#touchIdContainer").show();
            }

            function touchIsAvailableFailure() {
                $("#touchIdContainer").hide();
            }

            if (typeof TouchID !== "undefined") {
                // Checks to see if the device supports Touch Auth
                TouchID.isAvailable(touchIsAvailableSuccess, touchIsAvailableFailure);
            }           
        }
    };
})(jQuery);

//Contains functions/variables or anything that can be reused across this JS file.
var ClientTouchCommon = (function ($) {
    return {

        redirectToErrorPageURL: '/sso/Mobile/Error/Display',
        //This is the url to the error logging call for the WebAPI.
        errorAPIURL: '/sso/api/Logging/Log',
        //This function can be used in order to make an ajax call to the server.
        MakeAjaxCall: function (dataObject, headerObject, method, url, successCallback, failureCallback) {
            $.ajax({
                url: url,
                type: method,
                data: dataObject,
                cache: false, //If set to false, it will force requested pages not to be cached by the browser.
                headers: {}, //An object of additional header key/value pairs to send along with requests using the XMLHttpRequest transport.
                async: true, //If async is set to 'true', all requests are sent asynchronously
               contentType: 'application/x-www-form-urlencoded; charset=UTF-8',
                /*
                 * Before sending the request to the server, set the proper values in the header
                 * of the request if applicable. For example if we attemnpt to make a call to the
                 * WebAPI, the request verification token must be assigned to the header. in order
                 * to achieve this behavior, this function will do just that.
                 */
                beforeSend: function (xhr) {
                    /*
                     * Check to ensure that header properties are present prior to looping through
                     * the property of the JSON object and attempt to assign values to the header.
                     * If the object is null or undefined than this is an indication that no values
                     * must be appended to the header.
                     */
                    if (headerObject !== null && headerObject !== undefined) {
                        //Loop through the JSON properties and assign them to the header of the request.
                        for (var key in headerObject) {
                            if (headerObject.hasOwnProperty(key)) {
                                var val = headerObject[key];
                                xhr.setRequestHeader(key, val);
                            }
                        }
                    }
                },
                success: function (data, textStatus, jqXHR) {
                    //Check to determine whether the parameter passed in is of type "Function". If so execute the callback.
                    if (typeof (successCallback) === typeof (Function)) {
                        successCallback(data, textStatus, jqXHR);
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    //Check to determine whether the parameter passed in is of type "Function". If so execute the callback.
                    if (typeof (failureCallback) === typeof (Function)) {
                        failureCallback(jqXHR, textStatus, errorThrown);
                    }
                }
            });
        },
        /*
         * This function is designed in order to redirect the member to a generic error message in the event an exception has taken place
         * on the client side. 
         */
        RedirectToErrorPage: function (exception, errorSource, errorPageURL) {
            try {
                /*
                 * Check to determine whether the first parameter in the function is an instance of an error.
                 * If so, this is an indication that an exception was passed in; otherwise an exception is not
                 * present and therefore we do not need to communicate with the WebAPI to log an error. Simply
                 * redirect the member to the /sso/Mobile/Error/Display
                 */
                if (exception instanceof Error) {
                    var afToken = $("input[name='__RequestVerificationToken']").val();

                    if (afToken && afToken !== "") {

                        //This is the data in a json object which will be used in to be passed in to the data option as an object when making the ajax call
                        var headerObject = {
                            "__RequestVerificationToken": $("input[name='__RequestVerificationToken']").val()
                        };

                        //Generate a random request ID which is needed for the WebAPI request.
                        var requestID = MIDFLORIDAMobileCommon.GenerateGUID();

                        //Check whether the request ID has been properly generated. Do not proceed with the WebAPI call unless we have a valid request ID in a guid format.
                        if (requestID && requestID !== "") {

                            var errorString = ""; //This variable will hold all of the information in the exception which will be passed to the server to be logged.

                            //Check to ensure that we have an exception name before attempting to concatinate it to the error string that will be passed to the server.
                            if (exception.name && exception.name !== "") {
                                errorString = errorString.concat("Exception: " + exception.name + " | ");
                            }

                            //Check to ensure that we have an exception message before attempting to concatinate it to the error string that will be passed to the server.
                            if (exception.message && exception.message !== "") {
                                errorString = errorString.concat("Exception Message: " + exception.message + " | ");
                            }

                            //Check to ensure that we have an exception stack before attempting to concatinate it to the error string that will be passed to the server.
                            if (exception.stack && exception.stack !== "") {
                                errorString = errorString.concat("Exception Stack: " + exception.stack.toString() + " | ");
                            }

                            var errorData = {
                                RequestID: requestID,
                                ErrorToLog: errorString,
                                ClientSource: errorSource
                            };

                            ClientTouchCommon.MakeAjaxCall(errorData, headerObject, "POST", ClientTouchCommon.errorAPIURL, function () {
                                try {
                                    window.location = (ClientTouchCommon.redirectToErrorPageURL);
                                } catch (exception) { }
                            }, null);

                        } else {
                            //A valid request ID was not properly generated and therefore we cannot log the exception to the WebAPI. Redirect to the error page.
                            window.location = (ClientTouchCommon.redirectToErrorPageURL);
                        }
                    } else {
                        //A valid request ID was not properly generated and therefore we cannot log the exception to the WebAPI. Redirect to the error page
                        window.location = (ClientTouchCommon.redirectToErrorPageURL);
                    }
                } else {
                    //An exception object was not passed in to this function. Let's redirect the member to the generic error page.
                    window.location = (ClientTouchCommon.redirectToErrorPageURL);
                }

                //Acquiring the AF token from the form

            } catch (exception) {
                //Fail silently, this is the last safety net
            }
        },
        IsValidJSON: function (inObject) {
            try {
                JSON.parse(inObject);
            }
            catch (ex) {
                return true; //means it's already a proper object
            }

            return false;
        }
    };
})(jQuery);

var ClientTouchProfile = (function ($) {
    return {
        //This is the url which will be used in order to post to the server to enable touch ID feature.
        EnableTouchPostURL: '/sso/Mobile/Touch/EnableTouch',
        //This is the url which will be used in order to post to the server to disable touch ID feature.
        DeleteTouchPostURL: '/sso/Mobile/Touch/DeleteTouchLogin',
        //This variable contains the link to the Settings page
        SettingsPage: '/sso/Mobile/Settings',
        //This is the page that we will be using to redirect the member to in the event an error has occurred.
        ErrorPage: '/sso/Mobile/Error/Display',
        // This flag is used to determine if we need to route the member back to routing
        RedirectToRouting: false,
        //This is the touchID associated with the member.
        TouchID: null,
        /*
         * This property will hold a boolean value indicating whether the member has a touchID record set up in our system.
         * This value is returned from the server side.
         */
        IsDeviceEnabled: "",
        //This function is designed in order to determine whether the Touch is available
        DetermineTouchIDStatus: function () {
            try {
                //Determine whether the Touch feature is available on this device.
                TouchID.isAvailable(ClientTouchProfile.TouchIsAvailableSuccess, ClientTouchProfile.TouchIsAvailableFailure);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.DetermineTouchIDStatus()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is a call back function which will be called once the TouchID.isAvailable function
         * has completed processing. This will only be called on success.
         */
        TouchIsAvailableSuccess: function () {
            try {
                /*
                 * Determine whether the member has data already set up on the device. If data is present, the TouchHasDataSuccess success callback
                 * function will be called; otherwise the TouchHasDataFailure will be called.
                 */
                TouchID.hasUserData(ClientTouchProfile.TouchHasDataSuccess, ClientTouchProfile.TouchHasDataFailure);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.TouchIsAvailableSuccess()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is a call back function which will be called once the TouchID.isAvailable function
         * has completed processing. This will only be called on failure.
         */
        TouchIsAvailableFailure: function () {
            /*
             * This is the callback that fires when TouchID.isAvailable fails.
             * This is usually when the device supports Biometrics, but is not yet configured on the device.
             */
            //Disable the checkbox
            $('#EnableDisableTouchID').attr('disabled', true);

            //Show the message
            $('#PleaseEnableMessage').show();
        },
        /*
         * This function is a callback function which is called on success when the TouchID.hasUserData has completed
         * execution. The success is an indication that the device has data associated with this member. The function
         * will also check a value returned from the server to ensure that we are in sync. if this is the case, the
         * touchID toggle element will be set to ON. Otherwise, OFF.
         */
        TouchHasDataSuccess: function () {
            try {
                /*
                 * Check the value returned from the server side to determine whether we also have this device enabled on that side as well.
                 * If the value is true then this would be a clear indication that we are in sync and the TouchID switch must be set to ON.
                 */
                if (ClientTouchProfile.IsDeviceEnabled.toLocaleLowerCase() === "true") {
                    $("#EnableDisableTouchID").prop("checked", true);
                }
                /*
                 * Otherwise we must set it to OFF even though the device is indicating that we have user data which is not consistant with what
                 * was returned from the server. Obviously what was returned from the server wins over what the device is telling us.
                 */
                else {
                    $("#EnableDisableTouchID").prop("checked", false);
                }
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.TouchHasDataSuccess()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is a callback function which will be called on failure when the TouchID.hasUserData has completed
         * execution. When this function is called, it is an indication that the device does not contain the member's
         * data and therefore we must set the TouchID switch to OFF.
         */
        TouchHasDataFailure: function () {
            try {
                $("#EnableDisableTouchID").prop("checked", false);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.TouchHasDataFailure()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This function will be executed once the member toggles the switch for the TouchID. The function will make a
         * a determination as to whether the TouchID feature will either be enabled or disabled.
         */
        ToggleTouchFeature: function () {
            try {
                //Determine what the value of the TouchID switch is based on the member's action.
                var isEnabledTouch = $("#EnableDisableTouchID").is(":checked");

                /*
                 * If the value returned is true, then it is an indication that the member is requesting to have
                 * the touch feature be enabled on the device.
                 */
                if (isEnabledTouch) {

                    /*
                     * We must persist the member data on the device. If the call was successful, the EnableTouchFeature function
                     * will be executed; otherwise, the PersistCredentialsFailure function will be called instead.
                     */
                    TouchID.persistCredentials(ClientTouchProfile.TouchID,
                        ClientTouchProfile.EnableTouchFeature,
                        ClientTouchProfile.PersistCredentialsFailure);

                }
                //Otherwise, the member is requesting to have the touch feature be disabled on the device.
                else {
                    //Call the function to disable the TouchID feature.
                    ClientTouchProfile.DisableTouchFeature();
                }
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.ToggleTouchFeature()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This function is designed in order to enable the TouchID feature. The data has been persisted
         * on the device already and it is now time to communicate this event with the server side.
         * The function will
         *
         * @parameter: data which contains the following information
         *             1. TouchID
         *             2. Password
         *             3. Device Description
         */
        EnableTouchFeature: function (data) {
            try {
                //This object will contain the information that is needed to post to the server to enable the touch feature.
                var enableTouchFeatureData = null;

                //Parse the data object to a JSON object. For Android, the return data is already JSON, so we need to detect if we need to parse first
                var jsonParse = "";
                var isValidJSON = ClientTouchCommon.IsValidJSON(data);

                if (isValidJSON) {
                    jsonParse = data;
                }
                else {
                    jsonParse = JSON.parse(data);
                }

                if (jsonParse) {
                    //Acquiring the AF token from the form
                    var afToken = $("input[name='__RequestVerificationToken']").val();

                    if (afToken && afToken !== "") {

                        //This is the data in a json object which will be used in to be passed in to the data option as an object when making the ajax call
                        enableTouchFeatureData = {
                            "TouchID": jsonParse.TouchID,
                            "Password": jsonParse.TouchPassword,
                            "DeviceDescription": jsonParse.DeviceDescription,
                            "__RequestVerificationToken": afToken
                        };

                        if (jsonParse.TouchIDIV !== undefined) {
                            // we have a TouchIV back from the persistCredential call. Pass it along to our enable Touch POST
                            enableTouchFeatureData.TouchID_IV = jsonParse.TouchIDIV;
                        }

                        if (jsonParse.PasswordIV !== undefined) {
                            // we have a PasswordIV back from the persistCredential call. Pass it along to our enable Touch POST
                            enableTouchFeatureData.Password_IV = jsonParse.PasswordIV;
                        }

                        //Fire the enable feature call to save the information on the server side.
                        ClientTouchCommon.MakeAjaxCall(enableTouchFeatureData, null, "POST", ClientTouchProfile.EnableTouchPostURL, ClientTouchProfile.EnableTouchSuccess, ClientTouchProfile.EnableTouchFailure);
                    } else {
                        ClientTouchCommon.RedirectToErrorPage(
                            new Error("The Anti-Forgery Token could not be properly retrieved from the form when attempting to enable the touch feature."),
                            "ClientTouchID.ClientTouchProfile.EnableTouchFeature()", ClientTouchProfile.ErrorPage);
                    }
                } else {
                    ClientTouchCommon.RedirectToErrorPage(
                        new Error("An error has occurred while attemnpting to JSON parse the data object returned from the Cordova TouchID.persistCredentials() js method."),
                        "ClientTouchID.ClientTouchProfile.EnableTouchFeature()", ClientTouchProfile.ErrorPage);
                }
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.EnableTouchFeature()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is the callback function which will be called upon successful enabling of the touch login functionality.
         * This function will displaty the appropriate successful message on the view.
         */
        EnableTouchSuccess: function (data, textStatus, jqXHR) {
            try {
                /*
                 * We must first check to ensure that the status is a success and not any of these options:
                 *  1. timeout
                 *  2. error
                 *  3. notmodified
                 *  4. parsererror
                 */
                if (textStatus !== "success") {
                    ClientTouchCommon.RedirectToErrorPage(null, null, ClientTouchProfile.ErrorPage);
                }

            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.EnableTouchSuccess()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is the callback function which will be called upon failure during the enabling of the touch login functionality.
         * This function will redirect the member to a generic error page.
         */
        EnableTouchFailure: function (jqXHR, textStatus, errorThrown) {
            try {
                ClientTouchCommon.RedirectToErrorPage(null, null, ClientTouchProfile.ErrorPage);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.EnableTouchFailure()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This function is called upon a failure during the TouchID.persistCredentials() function call.
         * At this point the credential persistance was not successful and given the fact that the device
         * could not store the information, there is nothing we can do to proceed. Member will be redirected
         * to an error page which will display a generic error message.
         */
        PersistCredentialsFailure: function (data) {
            try {

                var errorJSON = JSON.parse(data);

                if (errorJSON.ErrorCode === "13") { // user cancelled the touch dialog
                    //Turn off the toggle
                    $("#EnableDisableTouchID").prop("checked", false);
                    TouchID.deleteCredentials(function () { }, ClientTouchProfile.DeleteCredentialsFailure);
                }
                else if (errorJSON.ErrorCode === "10") { // user cancelled the touch dialog
                    //Turn off the toggle
                    $("#EnableDisableTouchID").prop("checked", false);
                }
                else if (errorJSON.ErrorCode === "5") { // user cancelled the touch dialog
                    //Turn off the toggle
                    $("#EnableDisableTouchID").prop("checked", false);
                }
                else if (errorJSON.ErrorCode === "7") { // locked out for 30 seconds
                    //Turn off the toggle
                    $("#EnableDisableTouchID").prop("checked", false);
                    navigator.notification.alert(ClientTouchAuthenticate.BiometricAuthenticationAndroidTempLockoutMessageEnrollment, function () { }, '', 'OK');
                }
                else if (errorJSON.ErrorCode === "-1") //Touch ID is missing
                {
                    $("#EnableDisableTouchID").prop("checked", false);
                    navigator.notification.alert("Credential Error: " + ClientTouchAuthenticate.LoginToSetupTouchLoginMessage, function () { }, '', 'OK');
                }
                else {
                    ClientTouchCommon.RedirectToErrorPage(
                        new Error("An error has occurred while attempting to persist the member's credentials on the device. The Cordova TouchID.persistCredentials() js method executed the failure callback function. ErrorCode: " + errorJSON.ErrorCode + " | Error Description: " + errorJSON.ErrorDescription),
                        "ClientTouchID.ClientTouchProfile.PersistCredentialsFailure()", ClientTouchProfile.ErrorPage);
                }
               
            } catch (exception) {
                //Fail silently and do not take any other actions. 
            }
        },
        /*
         * This function is designed in order to disable/disenroll the member's device from TouchID
         */
        DisableTouchFeature: function () {
            try {
                //Acquiring the AF token from the form
                var afToken = $("input[name='__RequestVerificationToken']").val();

                if (afToken && afToken !== "") {

                    //This is the data in a json object which will be used in to be passed in to the data option as an object when making the ajax call
                    var data = {
                        "__RequestVerificationToken": $("input[name='__RequestVerificationToken']").val()
                    };

                    //Fire the enable feature call to disable the information on the server side.
                    ClientTouchCommon.MakeAjaxCall(data, null, "POST", ClientTouchProfile.DeleteTouchPostURL, ClientTouchProfile.DisableTouchSuccess, ClientTouchProfile.DisableTouchFailure);

                } else {
                    /*
                     * The anti-forgery token could not be retrieved from the page. The code cannot proceed.
                     * Redirect the member to a generic error page.
                     */
                    ClientTouchCommon.RedirectToErrorPage(
                        new Error("The Anti-Forgery Token could not be properly retrieved from the form when attempting to disable the touch feature."),
                        "ClientTouchID.ClientTouchProfile.DisableTouchFeature()", ClientTouchProfile.ErrorPage);
                }
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.DisableTouchFeature()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is the callback function which will be called upon success during the disabling of the touch login functionality.
         * This function will make a call to remove the credentials off of the device.
         */
        DisableTouchSuccess: function (data, textStatus, jqXHR) {
            try {
                /*
                 * Fire off a request to delete the credentials off of the phone by communiating with cordova.
                 * On a successful disabling of the touch feature do nothing.
                 * On a touch feature disabling failure we must redirect the member to the generic error page.
                 */
                TouchID.deleteCredentials(function () { }, ClientTouchProfile.DeleteCredentialsFailure);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.DisableTouchSuccess()", ClientTouchProfile.ErrorPage);
            }
        },
        /*
         * This is the callback function which will be called upon failure during the disabling of the touch login functionality.
         * This function will redirect the member to a generic error page.
         */
        DisableTouchFailure: function (jqXHR, textStatus, errorThrown) {
            try {
                ClientTouchCommon.RedirectToErrorPage(null, null, ClientTouchProfile.ErrorPage);
            } catch (exception) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.DisableTouchFailure()", ClientTouchProfile.ErrorPage);
            }
        },
        //This function is designed in order to process a failure during the removal of the credentials off of the device.
        DeleteCredentialsFailure: function () {
            try {
                ClientTouchCommon.RedirectToErrorPage(null, null, ClientTouchProfile.ErrorPage);
            }
            catch (exception) {
                //eat it
            }
        },
        SetTouchLoginSettingsLinkDisplay: function () {
            if (TouchID.isAvailable(
                function () { // success callback
                    // display the touch login link
                    $("#liTouchLoginLink").show();

                },
                function () { // failure callback
                    // no action required, the link will already be displayed
                }));
        },
        //Sends the user back to routing
        RedirectUserToRouting: function () {
            window.location = "/sso/Mobile/routing/index";
        },
        // determine if we should set a flag that will tell the server to return a TouchID to the client
        TouchIDRequestCheck: function (isTouchLoginEnabled) {
            try {
                TouchID.hasUserData(function () { }, function () {
                    try {
                        if (isTouchLoginEnabled && isTouchLoginEnabled.toLowerCase() === 'true') {
                            // the device does not have user data, meaning Touch login is not setup on this device, append a flag that will tell the server to return a TouchID for this user in the response
                            var touchIDLink = $('#hlTouchLoginSettings').attr('href');
                            $('#hlTouchLoginSettings').attr('href', touchIDLink + "/?requestTouchID=true");
                        }
                    } catch (err) {
                        ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.TouchIDRequestCheck()", ClientTouchProfile.ErrorPage);
                    }
                });
            } catch (err) {
                ClientTouchCommon.RedirectToErrorPage(exception, "ClientTouchID.ClientTouchProfile.TouchIDRequestCheck()", ClientTouchProfile.ErrorPage);
            }
        }
    };
})(jQuery);