﻿
function assignMask(hiddenfield, maskfield) {

    var actualInputUN = $(maskfield).val().trim();

    //If there's no value in the hidden field, no need to worry about re-masking
    if ($(hiddenfield).val().length === 0 || actualInputUN.indexOf('****') == -1) //Prevent re-masking
    {
        $(hiddenfield).val(actualInputUN);
        userAsteriskCount = 0; //reset the count

        if (actualInputUN.length > 4) {

            $(maskfield).val(actualInputUN.substring(0, 4) + '****');
        }
        else {
            if (actualInputUN.length > 0) {
                $(maskfield).val(actualInputUN + '****');
            }
        }
    }
    else //The hidden field is already populated, but the user possibly entered a username with 4+ asterisks.  How to we determine the difference between a masked username and a user-entered asterik
    {
        if (actualInputUN.indexOf('****') > -1) { //Check to see if the asterisks in the username box were user-entered, or a result of masking
            if (typeof (userAsteriskCount) !== "undefined" && userAsteriskCount > 0) {

                //Check to see if the count of user-entered asterisks matches how many are in the input box
                var inputBoxAsteriskCount = $(maskfield).val().split("*").length - 1; //Split is faster than using a regex and counting the matches.

                if (userAsteriskCount === inputBoxAsteriskCount) {
                    if (actualInputUN.length > 4) {

                        $(maskfield).val(actualInputUN.substring(0, 4) + '****');
                        $(hiddenfield).val(actualInputUN);
                    }
                    else {
                        if (actualInputUN.length > 0) {
                            $(maskfield).val(actualInputUN + '****');
                            $(hiddenfield).val(actualInputUN);
                        }
                    }

                    userAsteriskCount = 0; //reset the count
                }
                else {
                    //do nothing, just reset the count
                    userAsteriskCount = 0;
                }
            }
        }
    }
}